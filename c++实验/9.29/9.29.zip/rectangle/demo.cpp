//demo.cpp
#include<iostream>
#include"rect.h"
using namespace std;
int main()
{
	rect r1;
	r1.set();
	r1.get_r();
	return 0;
}
