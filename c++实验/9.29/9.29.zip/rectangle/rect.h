//rect.h
class rect
{
public:
	void set();
	void get_r();
private:
	int length;
	int width;
};