//Renminbi
class Renminbi
{
public:
	void display();
	void set();
private:
	int yuan;
	int jiao;
	int fen;
};